export const YOUTUBE_API_KEY = 'AIzaSyDmSuKkl7NVyEIlmqjgU8ZRQjmC5o0zbSk';
